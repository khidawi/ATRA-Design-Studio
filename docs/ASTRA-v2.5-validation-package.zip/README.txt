ASTRA research formal model v2.5: validation package
=====================================================
Document: ASTRA-Research-Formal-Modelv2.5.docx (Appendix B reports these checks).
Written by the author of the specification; NOT an independent reproduction (see Appendix B.1, B.12).

Contents
  AstraV25.tla                  TLA+ model of the transition system (section 3.5.2)
  run_tlc_v25.py                runs TLC in a Java 17 container for the specification and for planted defects
  tlc_trace_v25.py              prints the counterexample trace of one run
  modelcheck_v25.py             Python checks: gate with review, applicability, independence, organisation, delegation,
                                quantitative identities, static audit of the document text
  actions_v25.json              the action list of section 3.5.2 (guards, effects, writes) used by the static audit
  tlc_results_v25_spec.json     TLC results for the specification (states, depth, verdict)
  tlc_results_v25_mut.json      TLC results for the planted defects
  modelcheck_results_v25.json   results of modelcheck_v25.py
  tlc_logs_v25/                 raw TLC output and configuration of every run

Tools
  TLC from tla2tools.jar, SHA-256 8f719a6126a0922cf5a243f6c0ce73193b5c2e0a4e4cd29288ecc57a547f629d
  (downloaded from the TLA+ tools release page on GitHub; manifest Implementation-Version 2.0 2026-11-02, git revision 29980f0)
  Java: eclipse-temurin:17-jre (OpenJDK 17.0.20.1); Docker; Python 3 with numpy.

Reproduce
  1. Put tla2tools.jar in <system temp>/tla_probe/ (run_tlc_v25.py reads it from there).
  2. python -X utf8 run_tlc_v25.py spec     (specification; about 30 minutes, 4 cores)
  3. python -X utf8 run_tlc_v25.py mut      (planted defects)
  4. python -X utf8 modelcheck_v25.py       (reads ASTRA-Research-Formal-Modelv2.5.docx; set the paths at the top)
  Constants: CM=3, VE=2, VE2=3, AP_LEN=1, DR=1, DC=1; scenarios core (2 versions), core1, retire, incident.

Expected (specification runs): every run reports "Model checking completed. No error has been found."
  distinct states: core_safety 8,423,728, core1_safety_with_policy_change 164,192, core_live_auth 164,192, core_live_noauth 138,784, retire_safety 1,447,936, incident_safety_auth 964,176, incident_safety_noauth 658,336, incident_live_auth 964,176, incident_live_noauth 658,336
Expected (planted defects): every run reports a violation of the property named in Appendix B.6.
